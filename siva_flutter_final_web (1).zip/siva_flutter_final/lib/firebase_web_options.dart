import 'package:firebase_core/firebase_core.dart';

/// Firebase configuration used ONLY when the app runs in a browser.
/// Android and iOS read their config from google-services.json /
/// GoogleService-Info.plist instead. These values are public identifiers
/// (not secrets) copied from Firebase Console -> Project settings -> Web app.
const FirebaseOptions firebaseWebOptions = FirebaseOptions(
  apiKey: 'AIzaSyAIr51JlGYPlMpCjglEEUqBHKtd9pSGuqQ',
  authDomain: 'siva-9bf6c.firebaseapp.com',
  projectId: 'siva-9bf6c',
  storageBucket: 'siva-9bf6c.firebasestorage.app',
  messagingSenderId: '1055547100094',
  appId: '1:1055547100094:web:c609b061e6ef5b875907ef',
  measurementId: 'G-TR0G4B84V2',
);
