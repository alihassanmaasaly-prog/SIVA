import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _confirm = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إنشاء حساب')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(controller: _email, decoration: InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: const Icon(Icons.email), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))), keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr),
            const SizedBox(height: 16),
            TextField(controller: _pass, decoration: InputDecoration(labelText: 'كلمة المرور (6 أحرف على الأقل)', prefixIcon: const Icon(Icons.lock), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))), obscureText: true, textDirection: TextDirection.ltr),
            const SizedBox(height: 16),
            TextField(controller: _confirm, decoration: InputDecoration(labelText: 'تأكيد كلمة المرور', prefixIcon: const Icon(Icons.lock_outline), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))), obscureText: true, textDirection: TextDirection.ltr),
            if (_error != null) ...[const SizedBox(height: 12), Text(_error!, style: const TextStyle(color: Colors.red))],
            const SizedBox(height: 24),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _loading ? null : _register, child: _loading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('إنشاء حساب', style: TextStyle(fontSize: 16)))),
          ],
        ),
      ),
    );
  }

  Future<void> _register() async {
    if (_pass.text != _confirm.text) { setState(() => _error = 'كلمتا المرور غير متطابقتين'); return; }
    if (_pass.text.length < 6) { setState(() => _error = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'); return; }
    setState(() { _loading = true; _error = null; });
    final auth = context.read<AuthService>();
    final error = await auth.signUp(_email.text.trim(), _pass.text.trim());
    if (!mounted) return;
    setState(() { _loading = false; _error = error; });
    // On success AuthGate (the root route) now shows the dashboard; reveal it.
    if (error == null) Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override void dispose() { _email.dispose(); _pass.dispose(); _confirm.dispose(); super.dispose(); }
}
