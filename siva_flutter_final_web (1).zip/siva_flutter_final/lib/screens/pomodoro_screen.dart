import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/ad_service.dart';
import '../services/revenuecat_service.dart';

class PomodoroScreen extends StatefulWidget {
  const PomodoroScreen({super.key});
  @override State<PomodoroScreen> createState() => _PomodoroScreenState();
}

class _PomodoroScreenState extends State<PomodoroScreen> {
  int _seconds = 25 * 60;
  bool _isRunning = false;
  bool _isBreak = false;
  int _sessionCount = 0;
  Timer? _timer;

  void _startTimer() {
    if (_isRunning) return;
    setState(() => _isRunning = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_seconds > 0) { _seconds--; }
        else {
          _timer?.cancel(); _isRunning = false;
          if (!_isBreak) {
            _sessionCount++; _isBreak = true; _seconds = 5 * 60;
            _saveSession();
            final isPro = context.read<RevenueCatService>().isPro;
            if (!isPro) AdService.instance.maybeShowInterstitial();
          }
          else { _isBreak = false; _seconds = 25 * 60; }
        }
      });
    });
  }

  void _pauseTimer() { _timer?.cancel(); setState(() => _isRunning = false); }
  void _resetTimer() { _timer?.cancel(); setState(() { _isRunning = false; _isBreak = false; _seconds = 25 * 60; }); }

  Future<void> _saveSession() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).collection('study_sessions').add({
        'minutes': 25,
        'completedAt': Timestamp.now(),
      });
    } catch (_) {
      // Non-critical: if this fails (e.g. offline), we simply don't log the
      // session. The timer itself keeps working either way.
    }
  }

  String get _timeText { final m = (_seconds ~/ 60).toString().padLeft(2, '0'); final s = (_seconds % 60).toString().padLeft(2, '0'); return m + ':' + s; }
  double get _progress { final total = _isBreak ? 5 * 60 : 25 * 60; return _seconds / total; }

  @override void dispose() { _timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مؤقت بومودورو')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(color: Colors.teal.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
              child: Text('الجلسات المكتملة: ' + _sessionCount.toString(), style: const TextStyle(fontSize: 16, color: Colors.teal, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 40),
            CircularPercentIndicator(
              radius: 120,
              lineWidth: 12,
              percent: _progress,
              progressColor: _isBreak ? Colors.green : const Color(0xFF1A237E),
              backgroundColor: Colors.grey.shade200,
              circularStrokeCap: CircularStrokeCap.round,
              center: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(_timeText, style: TextStyle(fontSize: 56, fontWeight: FontWeight.bold, color: _isBreak ? Colors.green : const Color(0xFF1A237E))),
                  Text(_isBreak ? 'وقت الراحة' : 'وقت الدراسة', style: TextStyle(fontSize: 16, color: Colors.grey.shade600)),
                ],
              ),
            ),
            const SizedBox(height: 50),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingActionButton.large(heroTag: 'reset', backgroundColor: Colors.grey.shade200, foregroundColor: Colors.grey.shade800, onPressed: _resetTimer, child: const Icon(Icons.refresh, size: 32)),
                const SizedBox(width: 24),
                FloatingActionButton.large(heroTag: 'play', backgroundColor: _isRunning ? Colors.orange : const Color(0xFF1A237E), onPressed: _isRunning ? _pauseTimer : _startTimer, child: Icon(_isRunning ? Icons.pause : Icons.play_arrow, size: 40)),
              ],
            ),
            const SizedBox(height: 40),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 24),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.amber.shade50, borderRadius: BorderRadius.circular(16)),
              child: const Row(
                children: [
                  Icon(Icons.lightbulb, color: Colors.amber),
                  SizedBox(width: 12),
                  Expanded(child: Text('نصيحة: 25 دقيقة تركيز + 5 دقائق راحة = أفضل إنتاجية!', style: TextStyle(fontSize: 13))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
