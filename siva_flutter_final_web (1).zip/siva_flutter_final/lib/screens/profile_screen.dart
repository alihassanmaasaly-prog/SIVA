import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import '../services/auth_service.dart';
import '../services/revenuecat_service.dart';
import 'premium_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().user;
    final isPro = context.watch<RevenueCatService>().isPro;

    return Scaffold(
      appBar: AppBar(title: const Text('الحساب')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            CircleAvatar(radius: 50, backgroundColor: const Color(0xFF1A237E), child: Text((user?.email?.substring(0,1).toUpperCase() ?? 'U'), style: const TextStyle(fontSize: 36, color: Colors.white, fontWeight: FontWeight.bold))),
            const SizedBox(height: 16),
            Text(user?.email ?? 'مستخدم', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(color: isPro ? Colors.amber : Colors.grey.shade200, borderRadius: BorderRadius.circular(20)),
              child: Text(isPro ? 'SIVA Pro' : 'النسخة المجانية', style: TextStyle(fontSize: 13, color: isPro ? Colors.white : Colors.grey, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 32),

            if (!isPro)
              Card(
                color: Colors.amber.shade50,
                child: ListTile(
                  leading: const Icon(Icons.star, color: Colors.amber),
                  title: const Text('ترقّ إلى Pro'),
                  subtitle: const Text('افتح كل المزايا'),
                  trailing: const Icon(Icons.arrow_back_ios_new, size: 16),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PremiumScreen())),
                ),
              ),

            const SizedBox(height: 16),
            _buildMenuTile(Icons.share, 'مشاركة التطبيق', () => Share.share('حمّل تطبيق SIVA - منظم دراسة ذكي!')),
            _buildMenuTile(Icons.star_rate, 'تقييم التطبيق', () => launchUrl(Uri.parse('https://play.google.com/store/apps/details?id=com.siva.app'))),
            _buildMenuTile(Icons.privacy_tip, 'سياسة الخصوصية', () => launchUrl(Uri.parse('https://siva-9bf6c.web.app/privacy'))),
            _buildMenuTile(Icons.help, 'الدعم الفني', () => launchUrl(Uri.parse('mailto:support@siva.app'))),

            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  await context.read<AuthService>().signOut();
                  if (context.mounted) Navigator.of(context).popUntil((route) => route.isFirst);
                },
                icon: const Icon(Icons.logout), label: const Text('تسجيل الخروج'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuTile(IconData icon, String title, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(leading: Icon(icon, color: const Color(0xFF1A237E)), title: Text(title), trailing: const Icon(Icons.arrow_back_ios_new, size: 16, color: Colors.grey), onTap: onTap),
    );
  }
}
