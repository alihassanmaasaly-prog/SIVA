import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../services/ai_service.dart';
import '../services/revenuecat_service.dart';
import '../services/ad_service.dart';

class AIChatScreen extends StatefulWidget {
  const AIChatScreen({super.key});
  @override State<AIChatScreen> createState() => _AIChatScreenState();
}

class _ChatMessage {
  final String text;
  final bool isUser;
  _ChatMessage(this.text, this.isUser);
}

class _AIChatScreenState extends State<AIChatScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final _ai = AIService();
  final List<_ChatMessage> _messages = [];
  bool _loading = false;
  int _questionCount = 0;

  // The real daily quota (30 questions) is enforced server-side by the Cloudflare
  // Worker, which answers HTTP 429; AIService turns that into a friendly message.
  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _loading) return;

    final isPro = context.read<RevenueCatService>().isPro;

    setState(() {
      _messages.add(_ChatMessage(text, true));
      _ctrl.clear();
      _loading = true;
    });
    _scrollToBottom();

    try {
      final answer = await _ai.askStudyQuestion(text, 'عام');
      if (!mounted) return;
      setState(() {
        _messages.add(_ChatMessage(answer, false));
        _questionCount++;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _messages.add(_ChatMessage('حدث خطأ أثناء الاتصال بالمساعد. حاول مرة أخرى.', false));
      });
    } finally {
      if (mounted) setState(() => _loading = false);
      _scrollToBottom();

      // Show an interstitial ad every few questions for free users only.
      if (!isPro && _questionCount % 3 == 0) {
        AdService.instance.maybeShowInterstitial();
      }
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isPro = context.watch<RevenueCatService>().isPro;

    return Scaffold(
      appBar: AppBar(title: const Text('مساعد SIVA الذكي')),
      body: Column(
        children: [
          if (!isPro)
            Container(
              width: double.infinity,
              color: const Color(0xFFFFF3E0),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'الأسئلة المجانية: حتى 30 سؤالاً في اليوم',
                style: TextStyle(fontSize: 12, color: Colors.orange.shade800),
              ),
            ),
          Expanded(
            child: _messages.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text(
                        'اسأل مساعد SIVA الذكي أي سؤال دراسي، أو اطلب منه يلخّص لك درس، أو يسوي لك كويز.',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.cairo(color: Colors.grey.shade600),
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (ctx, i) {
                      final m = _messages[i];
                      return Align(
                        alignment: m.isUser ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                          decoration: BoxDecoration(
                            color: m.isUser ? const Color(0xFF1A237E) : Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(m.text, style: TextStyle(color: m.isUser ? Colors.white : Colors.black87)),
                        ),
                      );
                    },
                  ),
          ),
          if (_loading) const Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator()),
          // Banner ad above the input bar, shown only to non-Pro users.
          if (!isPro) const AdBannerWidget(),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    decoration: InputDecoration(
                      hintText: 'اكتب سؤالك هنا...',
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(
                  backgroundColor: const Color(0xFF1A237E),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 20),
                    onPressed: _send,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override void dispose() { _ctrl.dispose(); _scroll.dispose(); super.dispose(); }
}
