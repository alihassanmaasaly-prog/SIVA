import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import 'splash_screen.dart';
import 'login_screen.dart';
import 'dashboard_screen.dart';

/// Reactive root of the app. It always shows the screen that matches the
/// current auth state: the splash while the saved session is being resolved
/// (and for a short branding moment), the login screen when signed out, and
/// the dashboard when signed in. Because it listens to [AuthService], any
/// sign-in, sign-up or sign-out anywhere in the app swaps the screen
/// automatically - no manual Navigator calls are needed after auth actions.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool _minSplashElapsed = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _minSplashElapsed = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    if (auth.isLoading || !_minSplashElapsed) return const SplashScreen();
    return auth.user == null ? const LoginScreen() : const DashboardScreen();
  }
}
