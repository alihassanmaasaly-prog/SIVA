import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';

/// Calls our own Cloudflare Worker instead of talking to Gemini directly.
/// The real Gemini API key lives only on the Worker (cloudflare-worker/)
/// as a secret, never inside the app — so it can't be extracted by
/// decompiling the APK/IPA. The Worker verifies the user's Firebase login
/// before answering, so only signed-in users can use it.
class AIService {
  // TODO: replace with your deployed Worker URL after `wrangler deploy`,
  // e.g. https://siva-ai-proxy.yourname.workers.dev
  static const String _workerUrl = 'https://siva-ai-proxy.YOUR_SUBDOMAIN.workers.dev';

  Future<String> _call(String action, Map<String, dynamic> params) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return 'يجب تسجيل الدخول أولاً لاستخدام المساعد الذكي.';

      final idToken = await user.getIdToken();

      final response = await http.post(
        Uri.parse(_workerUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $idToken',
        },
        body: jsonEncode({'action': action, 'params': params}),
      );

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200) {
        final text = data['text'] as String?;
        return (text != null && text.trim().isNotEmpty) ? text : 'لم يصل رد من المساعد، حاول مرة أخرى.';
      }

      if (response.statusCode == 429) {
        return data['message'] as String? ?? 'تجاوزت الحد اليومي للأسئلة المجانية. جرب غداً أو اشترك بـ SIVA Pro.';
      }
      if (response.statusCode == 401) {
        return 'انتهت الجلسة، سجّل الدخول مرة أخرى.';
      }
      return 'حدث خطأ أثناء الاتصال بالمساعد. حاول مرة أخرى.';
    } catch (e) {
      return 'تعذر الاتصال بالخادم. تحقق من اتصالك بالإنترنت.';
    }
  }

  /// Study assistant - answers student questions
  Future<String> askStudyQuestion(String question, String subject) =>
      _call('askStudyQuestion', {'question': question, 'subject': subject});

  /// Summarize lessons - shortens any study text
  Future<String> summarizeText(String text) =>
      _call('summarizeText', {'text': text});

  /// Generate quiz questions
  Future<String> generateQuiz(String topic, int count) =>
      _call('generateQuiz', {'topic': topic, 'count': count});

  /// Smart study plan
  Future<String> createStudyPlan(String subjects, int days) =>
      _call('createStudyPlan', {'subjects': subjects, 'days': days});

  /// Explain difficult topic
  Future<String> explainTopic(String topic, String level) =>
      _call('explainTopic', {'topic': topic, 'level': level});

  /// Check homework
  Future<String> checkHomework(String question, String studentAnswer) =>
      _call('checkHomework', {'question': question, 'studentAnswer': studentAnswer});
}
