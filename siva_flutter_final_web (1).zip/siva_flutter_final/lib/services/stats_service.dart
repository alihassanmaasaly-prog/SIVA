import 'package:cloud_firestore/cloud_firestore.dart';

/// Aggregates real user data from Firestore for the dashboard.
/// Replaces the previous hardcoded placeholder numbers.
class DashboardStats {
  final int subjectsCount;
  final int totalTasks;
  final int completedTasks;
  final double totalStudyHours;
  final double weeklyStudyHours;

  const DashboardStats({
    required this.subjectsCount,
    required this.totalTasks,
    required this.completedTasks,
    required this.totalStudyHours,
    required this.weeklyStudyHours,
  });

  static const empty = DashboardStats(
    subjectsCount: 0, totalTasks: 0, completedTasks: 0,
    totalStudyHours: 0, weeklyStudyHours: 0,
  );

  double get taskCompletionPercent => totalTasks == 0 ? 0 : completedTasks / totalTasks;
}

class StatsService {
  final _db = FirebaseFirestore.instance;

  /// Combines subjects, tasks, and study-session streams into one
  /// dashboard-ready stats stream for the given user.
  Stream<DashboardStats> watchDashboardStats(String uid) {
    final subjectsStream = _db.collection('users').doc(uid).collection('subjects').snapshots();
    final tasksStream = _db.collection('users').doc(uid).collection('tasks').snapshots();
    final sessionsStream = _db.collection('users').doc(uid).collection('study_sessions').snapshots();

    // Combine three independent streams without extra packages: nest
    // StreamBuilders in the widget instead. This service exposes each
    // stream separately so the dashboard can compose them.
    return sessionsStream.asyncMap((sessionsSnap) async {
      final subjectsSnap = await subjectsStream.first;
      final tasksSnap = await tasksStream.first;
      return _computeStats(subjectsSnap, tasksSnap, sessionsSnap);
    });
  }

  Stream<QuerySnapshot> subjectsStream(String uid) =>
      _db.collection('users').doc(uid).collection('subjects').snapshots();

  Stream<QuerySnapshot> tasksStream(String uid) =>
      _db.collection('users').doc(uid).collection('tasks').snapshots();

  Stream<QuerySnapshot> studySessionsStream(String uid) =>
      _db.collection('users').doc(uid).collection('study_sessions').snapshots();

  DashboardStats _computeStats(QuerySnapshot subjects, QuerySnapshot tasks, QuerySnapshot sessions) {
    final totalTasks = tasks.docs.length;
    final completedTasks = tasks.docs.where((d) => (d.data() as Map<String, dynamic>)['isCompleted'] == true).length;

    int totalMinutes = 0;
    int weeklyMinutes = 0;
    final weekAgo = DateTime.now().subtract(const Duration(days: 7));
    for (final doc in sessions.docs) {
      final data = doc.data() as Map<String, dynamic>;
      final minutes = (data['minutes'] ?? 25) as int;
      totalMinutes += minutes;
      final completedAt = (data['completedAt'] as Timestamp?)?.toDate();
      if (completedAt != null && completedAt.isAfter(weekAgo)) {
        weeklyMinutes += minutes;
      }
    }

    return DashboardStats(
      subjectsCount: subjects.docs.length,
      totalTasks: totalTasks,
      completedTasks: completedTasks,
      totalStudyHours: totalMinutes / 60,
      weeklyStudyHours: weeklyMinutes / 60,
    );
  }
}
