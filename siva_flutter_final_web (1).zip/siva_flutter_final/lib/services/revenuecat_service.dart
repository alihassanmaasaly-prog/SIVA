import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class RevenueCatService extends ChangeNotifier {
  bool _isPro = false;
  bool _isLoading = true;
  Offerings? _offerings;

  bool get isPro => _isPro;
  bool get isLoading => _isLoading;
  Offerings? get offerings => _offerings;

  // RevenueCat public SDK keys - loaded from .env. RevenueCat uses a DIFFERENT
  // key per store: Android needs the Google Play key (starts with goog_),
  // iOS needs the App Store key (starts with appl_).
  static String get _apiKey {
    if (kIsWeb) return '';
    if (defaultTargetPlatform == TargetPlatform.android) return dotenv.env['REVENUECAT_API_KEY_ANDROID'] ?? '';
    if (defaultTargetPlatform == TargetPlatform.iOS) return dotenv.env['REVENUECAT_API_KEY_IOS'] ?? '';
    return '';
  }

  Future<void> init() async {
    try {
      if (_apiKey.isEmpty) {
        // No key for this platform yet: run as a free-tier app instead of failing.
        debugPrint('RevenueCat key missing for this platform - purchases disabled.');
      } else {
        await Purchases.setLogLevel(LogLevel.debug);
        await Purchases.configure(
          PurchasesConfiguration(_apiKey)
            ..appUserID = null,
        );
        await _checkProStatus();
        await _fetchOfferings();
      }
    } catch (e) {
      debugPrint('RevenueCat init error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> _checkProStatus() async {
    try {
      final customerInfo = await Purchases.getCustomerInfo();
      _isPro = customerInfo.entitlements.all['pro']?.isActive ?? false;
      notifyListeners();
    } catch (e) {
      debugPrint('Error checking pro status: $e');
    }
  }

  Future<void> _fetchOfferings() async {
    try {
      _offerings = await Purchases.getOfferings();
      notifyListeners();
    } catch (e) {
      debugPrint('Error fetching offerings: $e');
    }
  }

  Future<bool> purchasePackage(Package package) async {
    try {
      final customerInfo = await Purchases.purchasePackage(package);
      _isPro = customerInfo.entitlements.all['pro']?.isActive ?? false;
      notifyListeners();
      return _isPro;
    } catch (e) {
      debugPrint('Purchase error: $e');
      return false;
    }
  }

  Future<void> restorePurchases() async {
    try {
      final customerInfo = await Purchases.restorePurchases();
      _isPro = customerInfo.entitlements.all['pro']?.isActive ?? false;
      notifyListeners();
    } catch (e) {
      debugPrint('Restore error: $e');
    }
  }
}
