import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Central place for AdMob setup and interstitial ad management.
///
/// Ad unit IDs below are Google's official PUBLIC TEST IDs — safe to ship
/// during development, but they only ever show Google's test creative and
/// earn no revenue. Before publishing to Google Play / App Store, replace
/// them with your own IDs from admob.google.com (see comments below).
class AdService {
  AdService._();
  static final AdService instance = AdService._();

  InterstitialAd? _interstitialAd;
  int _interstitialLoadAttempts = 0;
  static const int _maxLoadAttempts = 3;

  static String get bannerAdUnitId {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return 'ca-app-pub-3940256099942544/6300978111'; // TODO: replace with your real Android banner ID
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      return 'ca-app-pub-3940256099942544/2934735716'; // TODO: replace with your real iOS banner ID
    }
    throw UnsupportedError('Unsupported platform for ads');
  }

  static String get interstitialAdUnitId {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return 'ca-app-pub-3940256099942544/1033173712'; // TODO: replace with your real Android interstitial ID
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      return 'ca-app-pub-3940256099942544/4411468910'; // TODO: replace with your real iOS interstitial ID
    }
    throw UnsupportedError('Unsupported platform for ads');
  }

  Future<void> initialize() async {
    if (kIsWeb) return; // AdMob does not exist on the web build
    await MobileAds.instance.initialize();
    _loadInterstitial();
  }

  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _interstitialLoadAttempts = 0;
          _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _interstitialAd = null;
              _loadInterstitial(); // pre-load the next one
            },
            onAdFailedToShowFullScreenContent: (ad, error) {
              ad.dispose();
              _interstitialAd = null;
              _loadInterstitial();
            },
          );
        },
        onAdFailedToLoad: (error) {
          _interstitialLoadAttempts++;
          _interstitialAd = null;
          if (_interstitialLoadAttempts < _maxLoadAttempts) {
            _loadInterstitial();
          }
        },
      ),
    );
  }

  /// Call this at natural break points (e.g. after finishing a Pomodoro
  /// session, or every few AI questions). Silently does nothing if no ad
  /// is loaded yet, so it's always safe to call.
  void maybeShowInterstitial() {
    if (_interstitialAd != null) {
      _interstitialAd!.show();
    }
  }
}

/// A ready-to-use banner ad widget. Place it wherever you want a banner
/// to appear (e.g. above the input bar, or at the bottom of a screen).
/// It disposes itself correctly and shows nothing while loading/on failure.
class AdBannerWidget extends StatefulWidget {
  const AdBannerWidget({super.key});
  @override State<AdBannerWidget> createState() => _AdBannerWidgetState();
}

class _AdBannerWidgetState extends State<AdBannerWidget> {
  BannerAd? _bannerAd;
  bool _isLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBanner();
  }

  void _loadBanner() {
    if (kIsWeb) return; // no banner ads in the browser
    _bannerAd = BannerAd(
      adUnitId: AdService.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) => setState(() => _isLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          setState(() => _isLoaded = false);
        },
      ),
    )..load();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isLoaded || _bannerAd == null) return const SizedBox.shrink();
    return Container(
      alignment: Alignment.center,
      width: _bannerAd!.size.width.toDouble(),
      height: _bannerAd!.size.height.toDouble(),
      child: AdWidget(ad: _bannerAd!),
    );
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }
}
