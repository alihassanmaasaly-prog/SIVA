import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? _user;
  bool _isLoading = true;

  User? get user => _user;
  bool get isLoading => _isLoading;

  AuthService() {
    _auth.authStateChanges().listen((user) {
      _user = user;
      _isLoading = false;
      notifyListeners();
    });
  }

  Future<String?> signIn(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return null;
    } on FirebaseAuthException catch (e) {
      return _getErrorMessage(e.code);
    }
  }

  Future<String?> signUp(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
      return null;
    } on FirebaseAuthException catch (e) {
      return _getErrorMessage(e.code);
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  String _getErrorMessage(String code) {
    switch (code) {
      case 'invalid-credential': return 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
      case 'user-not-found': return 'البريد الإلكتروني غير مسجّل';
      case 'wrong-password': return 'كلمة المرور غير صحيحة';
      case 'invalid-email': return 'البريد الإلكتروني غير صالح';
      case 'weak-password': return 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
      case 'email-already-in-use': return 'البريد الإلكتروني مستخدم مسبقاً';
      default: return 'حدث خطأ، حاول مرة أخرى';
    }
  }
}
