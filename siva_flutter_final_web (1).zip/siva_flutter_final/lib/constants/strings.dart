/// نصوص وسلاسل التطبيق المركزية - كل النصوص بمكان واحد
/// هذا يسهل التحديثات والترجمة والصيانة

class AppStrings {
  // الشاشات الأساسية
  static const String appTitle = 'SIVA';
  static const String appTagline = 'منظم دراسة ذكي';

  // شاشة التسجيل
  static const String loginTitle = 'تسجيل الدخول';
  static const String registerTitle = 'إنشاء حساب';
  static const String emailLabel = 'البريد الإلكتروني';
  static const String passwordLabel = 'كلمة المرور';
  static const String confirmPasswordLabel = 'تأكيد كلمة المرور';
  static const String loginButton = 'تسجيل الدخول';
  static const String registerButton = 'إنشاء حساب';
  static const String noAccountText = 'ما عندك حساب؟ سجّل الآن';
  static const String passwordMismatch = 'كلمتا المرور غير متطابقتين';
  static const String weakPassword = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';

  // رسائل الأخطاء من Firebase
  static const String userNotFound = 'البريد الإلكتروني غير مسجّل';
  static const String wrongPassword = 'كلمة المرور غير صحيحة';
  static const String invalidEmail = 'البريد الإلكتروني غير صالح';
  static const String emailInUse = 'البريد الإلكتروني مستخدم مسبقاً';
  static const String genericError = 'حدث خطأ، حاول مرة أخرى';

  // الشاشة الرئيسية (الداشبورد)
  static const String homeTitle = 'الرئيسية';
  static const String welcomePrefix = 'أهلاً، ';
  static const String freeVersion = 'النسخة المجانية';
  static const String encouragement = 'استمر، اليوم يومك!';
  
  // الإحصائيات
  static const String subjects = 'المواد';
  static const String tasks = 'المهام';
  static const String hours = 'الساعات';
  static const String weeklyProgress = 'التقدم الأسبوعي';
  static const String completedTasks = 'أنجزت';
  static const String of = 'من';
  static const String tasksShort = 'مهمة';
  static const String weeklyStudyHours = 'ساعة دراسة هذا الأسبوع';
  static const String quickAccess = 'الوصول السريع';
  
  // الأزرار السريعة
  static const String addNewSubject = 'إضافة مادة جديدة';
  static const String addNewTask = 'إضافة مهمة جديدة';
  static const String startStudySession = 'بدء جلسة دراسة';
  static const String aiAssistant = 'مساعد SIVA الذكي';

  // عرض SIVA Pro
  static const String sivaProTitle = 'SIVA Pro';
  static const String proFeatures = 'مواد غير محدودة + بدون إعلانات + تحليل ذكي';
  static const String upgradeButton = 'ترقية';

  // التنقل السفلي
  static const String navigationHome = 'الرئيسية';
  static const String navigationSubjects = 'المواد';
  static const String navigationTasks = 'المهام';
  static const String navigationTimer = 'المؤقت';
  static const String navigationNotes = 'الملاحظات';

  // شاشة المواد
  static const String subjectsTitle = 'المواد الدراسية';
  static const String addSubjectCard = 'إضافة مادة جديدة';
  static const String subjectName = 'اسم المادة';
  static const String chooseColor = 'اختر لوناً:';
  static const String addSubjectButton = 'إضافة مادة';
  static const String hoursPerWeek = 'ساعة/أسبوع';
  static const String deleteAction = 'حذف';

  // شاشة المهام
  static const String tasksTitle = 'المهام والواجبات';
  static const String addTask = 'إضافة مهمة جديدة';
  static const String taskTitle = 'عنوان المهمة';
  static const String selectSubject = 'المادة';
  static const String dueDate = 'تاريخ التسليم: ';
  static const String priority = 'الأولوية: ';
  static const String priorityNormal = 'عادية';
  static const String priorityImportant = 'مهمة';
  static const String priorityUrgent = 'عاجلة';
  static const String addTaskButton = 'إضافة مهمة';
  static const String noTasks = 'لا توجد مهام بعد';

  // شاشة البومودورو
  static const String pomodoroTitle = 'مؤقت بومودورو';
  static const String completedSessions = 'الجلسات المكتملة: ';
  static const String studyTime = 'وقت الدراسة';
  static const String breakTime = 'وقت الراحة';
  static const String pomodoroTip = 'نصيحة: 25 دقيقة تركيز + 5 دقائق راحة = أفضل إنتاجية!';

  // شاشة الملاحظات
  static const String notesTitle = 'الملاحظات';
  static const String addNote = 'إضافة ملاحظة';
  static const String noteTitle = 'عنوان الملاحظة';
  static const String noteContent = 'المحتوى';
  static const String saveChanges = 'حفظ التعديلات';
  static const String cancelButton = 'إلغاء';
  static const String editAction = 'تعديل';
  static const String noNotes = 'لا توجد ملاحظات بعد';

  // شاشة المساعد الذكي
  static const String aiTitle = 'مساعد SIVA الذكي';
  static const String askQuestion = 'اكتب سؤالك هنا...';
  static const String quotaExceeded = 'تجاوزت الحد اليومي للأسئلة المجانية. جرب غداً أو اشترك بـ SIVA Pro.';
  static const String aiError = 'حدث خطأ أثناء الاتصال بالمساعد الذكي.';
  static const String networkError = 'تعذر الاتصال بالخادم. تحقق من اتصالك بالإنترنت.';
  static const String sessionExpired = 'انتهت الجلسة، سجّل الدخول مرة أخرى.';

  // شاشة الشات
  static const String chatTitle = 'شات مجتمع SIVA';
  static const String typeMessage = 'اكتب رسالة...';
  static const String userPlaceholder = 'مستخدم';

  // شاشة الحساب
  static const String accountTitle = 'الحساب';
  static const String upgradeToPro = 'ترقّ إلى Pro';
  static const String unlockAllFeatures = 'افتح كل المزايا';
  static const String shareApp = 'مشاركة التطبيق';
  static const String shareMessage = 'حمّل تطبيق SIVA - منظم دراسة ذكي!';
  static const String rateApp = 'تقييم التطبيق';
  static const String privacyPolicy = 'سياسة الخصوصية';
  static const String support = 'الدعم الفني';
  static const String logout = 'تسجيل الخروج';

  // شاشة الاشتراك
  static const String premiumTitle = 'ترقّ إلى SIVA Pro';
  static const String unlockPotential = 'افتح إمكانياتك الدراسية الكاملة';
  static const String unlimitedSubjects = 'مواد غير محدودة';
  static const String addAnySubjects = 'أضف أي عدد من المواد الدراسية';
  static const String noAds = 'بدون إعلانات';
  static const String cleanExperience = 'تجربة نظيفة بدون أي إعلانات';
  static const String smartAnalysis = 'تحليل ذكي';
  static const String knowStrengths = 'اعرف نقاط قوتك وضعفك';
  static const String cloudSync = 'مزامنة سحابية';
  static const String dataInCloud = 'بياناتك محفوظة وآمنة بالسحابة';
  static const String exclusiveThemes = 'مظاهر حصرية';
  static const String customizeApp = 'خصّص التطبيق كما يعجبك';
  static const String weeklyPlan = 'أسبوعي';
  static const String weeklyTrial = 'تجربة أسبوع واحد';
  static const String monthlyPlan = 'شهري';
  static const String mostPopular = 'الأكثر شيوعاً';
  static const String yearlyPlan = 'سنوي';
  static const String yearlySave = 'وفّر 45% + شهرين مجاناً';
  static const String restorePurchases = 'استعادة المشتريات';
  static const String upgradeSuccess = 'تمت الترقية إلى Pro!';

  // رسائل عامة
  static const String loading = 'جاري التحميل...';
  static const String noNetwork = 'لا يوجد اتصال بالإنترنت';
  static const String pleaseLoin = 'يرجى تسجيل الدخول';
  static const String ok = 'حسناً';
  static const String cancel = 'إلغاء';
  static const String save = 'حفظ';
  static const String delete = 'حذف';
  static const String edit = 'تعديل';
  static const String close = 'إغلاق';
  static const String back = 'رجوع';

  // نصائح
  static const String tip = 'نصيحة: ';
  static const String keepTracks = 'احفظ أي معلومة بسهولة واحصل عليها متى احتجتها!';
  static const String focusWins = '25 دقيقة تركيز > ساعات من الدراسة السطحية!';
  static const String communicate = 'تواصل مع طلاب آخرين وشارك الأفكار!';

  // الرسائل الترحيبية
  static const String welcomeMessage = 'أهلاً وسهلاً بك في SIVA!';
  static const String getStartedMessage = 'ابدأ بإضافة مواديك الأولى الآن.';

  // جملة الختام
  static const String successMessage = 'نجاحك = نجاحنا! 🚀';
}

/// فئة للمساعدة في الترجمة والتطوير المستقبلي
class AppMessages {
  static String congratulations(int count) {
    if (count == 1) return 'مبروك! أنجزت مهمة واحدة اليوم';
    if (count <= 3) return 'رائع! أنجزت $count مهام اليوم';
    if (count <= 5) return 'ممتاز! أنجزت $count مهام اليوم';
    return 'استثنائي! أنجزت $count مهام اليوم';
  }

  static String studyStreak(int days) {
    return 'سلسلة دراسة: $days يوم متتالي 🔥';
  }

  static String dailyQuotaRemaining(int remaining) {
    return '$remaining أسئلة متبقية اليوم';
  }

  static String tasksDueIn(int days) {
    if (days == 0) return 'مهام تنتهي اليوم!';
    if (days == 1) return 'مهام تنتهي غداً';
    return 'مهام تنتهي في $days أيام';
  }

  static String hoursStudiedThisWeek(double hours) {
    return 'درست ${hours.toStringAsFixed(1)} ساعة هذا الأسبوع';
  }
}
