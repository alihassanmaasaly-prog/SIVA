import { createRemoteJWKSet, jwtVerify } from 'jose';

// Firebase ID tokens are signed by Google and can be verified with this
// public key set — no Firebase Admin SDK needed here.
const JWKS = createRemoteJWKSet(
  new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com')
);

const FREE_DAILY_LIMIT = 30;
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

/** Verifies the Firebase ID token sent by the Flutter app and returns the uid. */
async function verifyFirebaseToken(idToken, projectId) {
  const { payload } = await jwtVerify(idToken, JWKS, {
    issuer: `https://securetoken.google.com/${projectId}`,
    audience: projectId,
  });
  if (!payload.sub) throw new Error('Token missing subject');
  return payload.sub; // this is the Firebase uid
}

/** Builds the actual Gemini prompt server-side, so the client can only pick
 *  from a known set of actions/params — never send a raw arbitrary prompt. */
function buildPrompt(action, params = {}) {
  switch (action) {
    case 'askStudyQuestion':
      return `You are an expert Arabic study assistant specializing in ${params.subject || 'عام'}. Answer this question in simple Arabic for students: ${params.question || ''}`;
    case 'summarizeText':
      return `Summarize this study text into main points in Arabic: ${params.text || ''}`;
    case 'generateQuiz':
      return `Create ${params.count || 5} multiple choice questions in Arabic about: ${params.topic || ''}. Each question has 4 options (A B C D). Mark correct answer.`;
    case 'createStudyPlan':
      return `Create a detailed Arabic study plan for ${params.days || 7} days for subjects: ${params.subjects || ''}. Include daily schedule with Pomodoro breaks.`;
    case 'explainTopic':
      return `Explain this topic in simple Arabic for ${params.level || 'مبتدئ'} level: ${params.topic || ''}. Use daily life examples. Divide into: Definition, Main Idea, Examples, Application.`;
    case 'checkHomework':
      return `You are an Arabic teacher. Review this homework. Question: ${params.question || ''}. Student Answer: ${params.studentAnswer || ''}. Evaluate in Arabic. Be encouraging.`;
    default:
      throw new Error('Unknown action: ' + action);
  }
}

async function checkAndIncrementQuota(env, uid) {
  const today = new Date().toISOString().slice(0, 10);
  const key = `${uid}:${today}`;
  const current = parseInt((await env.QUOTA.get(key)) || '0', 10);
  if (current >= FREE_DAILY_LIMIT) {
    throw Object.assign(new Error('تجاوزت الحد اليومي للأسئلة. حاول غداً أو اشترك بـ SIVA Pro.'), { code: 'quota' });
  }
  // expirationTtl clears the counter automatically after ~2 days
  await env.QUOTA.put(key, String(current + 1), { expirationTtl: 172800 });
}

async function callGemini(env, prompt) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${env.GEMINI_API_KEY}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error('Gemini API error: ' + errText);
  }
  const data = await res.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS_HEADERS });
    if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

    try {
      const authHeader = request.headers.get('Authorization') || '';
      const idToken = authHeader.replace('Bearer ', '');
      if (!idToken) return json({ error: 'unauthenticated', message: 'Sign in required.' }, 401);

      const uid = await verifyFirebaseToken(idToken, env.FIREBASE_PROJECT_ID);

      const { action, params } = await request.json();
      if (!action) return json({ error: 'invalid-argument', message: 'Missing action' }, 400);

      await checkAndIncrementQuota(env, uid);

      const prompt = buildPrompt(action, params);
      const text = await callGemini(env, prompt);

      return json({ text });
    } catch (err) {
      if (err.code === 'quota') return json({ error: 'resource-exhausted', message: err.message }, 429);
      if (err.message?.includes('JWT') || err.message?.includes('signature')) {
        return json({ error: 'unauthenticated', message: 'Invalid session, please sign in again.' }, 401);
      }
      console.error(err);
      return json({ error: 'internal', message: 'حدث خطأ أثناء الاتصال بالمساعد الذكي.' }, 500);
    }
  },
};
