# إعداد حماية مفتاح Gemini (Cloudflare Workers - مجاني 100%، بدون بطاقة)

هذا البديل المجاني الكامل عن Firebase Cloud Functions. Firestore وتسجيل
الدخول (Firebase Auth) باقيين زي ما هم - مجانيين تماماً وما يحتاجون بطاقة.
بس حماية مفتاح Gemini انتقلت إلى Cloudflare Worker (مجاني، 100 ألف طلب
باليوم، تسجيل بإيميل بس بدون أي بطاقة ائتمانية).

## الخطوات

1. أنشئ حساب مجاني على `https://dash.cloudflare.com/sign-up` (إيميل وكلمة
   مرور بس، بدون بطاقة).

2. ثبّت أدوات Cloudflare على جهازك (تحتاج Node.js مثبت مسبقاً، نفس اللي
   ثبّتناه قبل شوي):
   ```
   cd cloudflare-worker
   npm install
   ```

3. سجّل دخول من سطر الأوامر:
   ```
   npx wrangler login
   ```
   بيفتح المتصفح تسجّل فيه دخول بنفس حساب Cloudflare.

4. أنشئ مخزن KV (يُستخدم لعدّ الأسئلة اليومية لكل مستخدم):
   ```
   npx wrangler kv namespace create "QUOTA"
   ```
   الأمر يطبع لك سطر فيه `id = "...."` — انسخ القيمة هذي وحطها بملف
   `wrangler.toml` مكان `PASTE_YOUR_KV_NAMESPACE_ID_HERE`.

5. خزّن مفتاح Gemini الحقيقي (أنشئ مفتاح جديد من Google AI Studio أولاً،
   لأن القديم كان مكشوف بالكود سابقاً ولازم يُلغى):
   ```
   npx wrangler secret put GEMINI_API_KEY
   ```
   يطلب منك تلصق المفتاح، الصقه واضغط Enter.

6. خزّن رقم مشروع Firebase (عشان الـ Worker يتحقق من تسجيل الدخول):
   ```
   npx wrangler secret put FIREBASE_PROJECT_ID
   ```
   اكتب: `siva-9bf6c`

7. انشر الـ Worker:
   ```
   npx wrangler deploy
   ```
   بعد النجاح، يطبع لك رابط شبيه بـ:
   `https://siva-ai-proxy.YOUR_SUBDOMAIN.workers.dev`

8. افتح ملف `lib/services/ai_service.dart` بالتطبيق، وبدّل السطر:
   ```dart
   static const String _workerUrl = 'https://siva-ai-proxy.YOUR_SUBDOMAIN.workers.dev';
   ```
   بالرابط الحقيقي اللي طلع لك بالخطوة السابقة.

9. من مجلد المشروع الرئيسي:
   ```
   flutter pub get
   ```

10. جرّب شاشة "SIVA AI Assistant" — لازم تشتغل بدون أي مفتاح داخل التطبيق.

## ملاحظات
- الحد اليومي الافتراضي 30 سؤال لكل مستخدم (تقدر تغيّره بـ
  `FREE_DAILY_LIMIT` بملف `cloudflare-worker/src/index.js`).
- تنشر أي تعديل جديد على الـ Worker لاحقاً بنفس أمر:
  `npx wrangler deploy` من داخل مجلد `cloudflare-worker`.
- قواعد أمان Firestore (`firestore.rules`) تُنشر بشكل منفصل ومجاني بالكامل
  عبر:
  ```
  npm install -g firebase-tools
  firebase login
  firebase use --add   (اختر siva-9bf6c)
  firebase deploy --only firestore:rules
  ```
  هذا الجزء لا يحتاج خطة Blaze ولا بطاقة، لأنه بس قواعد أمان مو دالة تشغيل.
