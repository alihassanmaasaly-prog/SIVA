import 'package:flutter_test/flutter_test.dart';
import 'package:siva/services/stats_service.dart';

void main() {
  group('DashboardStats', () {
    test('empty stats have zero completion', () {
      expect(DashboardStats.empty.taskCompletionPercent, 0);
    });

    test('completion percent is completed / total', () {
      const stats = DashboardStats(
        subjectsCount: 2, totalTasks: 4, completedTasks: 1,
        totalStudyHours: 1.5, weeklyStudyHours: 0.5,
      );
      expect(stats.taskCompletionPercent, 0.25);
    });
  });
}
